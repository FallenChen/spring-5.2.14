/**
 * Spring's variant of the AOP Alliance interfaces.
 */
package org.aopalliance;
